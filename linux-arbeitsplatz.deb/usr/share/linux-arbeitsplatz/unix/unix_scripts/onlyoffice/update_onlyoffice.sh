cd /root/onlyoffice

docker rm -f onlyoffice
bash run.sh