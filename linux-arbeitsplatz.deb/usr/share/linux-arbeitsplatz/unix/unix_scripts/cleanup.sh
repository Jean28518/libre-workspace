apt clean
apt autoremove -y

docker image prune -a -f