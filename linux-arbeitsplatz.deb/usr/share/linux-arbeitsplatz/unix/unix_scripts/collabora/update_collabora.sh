cd /root/collabora

docker rm -f collabora
bash run.sh