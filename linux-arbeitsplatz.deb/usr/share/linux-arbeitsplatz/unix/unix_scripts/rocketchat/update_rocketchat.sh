cd /root/rocket.chat

# Update Rocket.Chat
docker-compose pull
docker-compose up -d