IP_ADDR=$(hostname -I | cut -d' ' -f1)
echo $IP_ADDR