export IP="192.168.178.75"
export ADMIN_PASSWORD="LibreWorkspace"
export DOMAIN="int.de"